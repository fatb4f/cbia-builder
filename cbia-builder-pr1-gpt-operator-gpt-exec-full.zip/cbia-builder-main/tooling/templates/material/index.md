# Material Index (template)

This is a template. Real material lives under each project:
- `<project>/material/index.md`

Recommended structure:
- `material/index.md`
- `material/modules/<module-id>/...`
