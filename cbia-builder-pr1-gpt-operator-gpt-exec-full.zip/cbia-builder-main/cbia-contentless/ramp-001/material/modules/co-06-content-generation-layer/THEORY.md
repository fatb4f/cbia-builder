    # Theory — co-06

    # co-06-content-generation-layer — theory

**Status:** stub

## Minimal lecture

- See `minimal_lecture` field (stub).

## Drills

- See `drill_prompts` field (stub).
