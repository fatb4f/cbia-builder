# Drills — co-06

## Drill 1
STUB: Micro-drill 1 (inputs → outputs).

## Drill 2
STUB: Micro-drill 2 (inputs → outputs).

## Drill 3
STUB: Micro-drill 3 (inputs → outputs).
