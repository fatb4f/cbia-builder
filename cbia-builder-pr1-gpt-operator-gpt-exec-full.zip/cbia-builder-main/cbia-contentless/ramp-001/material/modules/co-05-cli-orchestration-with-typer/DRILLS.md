# Drills

1. Write unit tests for two pure operators.
2. Introduce a deliberate bug and confirm the test catches it.
3. Remove the bug and confirm tests pass again.

---

# Drills

1. Write a CLI wrapper for an existing operator.
2. Ensure the operator can be tested without invoking the CLI.
3. Verify invalid arguments produce non-zero exit codes.
