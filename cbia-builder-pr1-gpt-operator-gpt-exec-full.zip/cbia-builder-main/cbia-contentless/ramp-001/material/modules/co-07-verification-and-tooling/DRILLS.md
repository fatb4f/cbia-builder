# Drills

1. Review one module and document its failure modes.
2. Add assertions or validations to enforce assumptions.
3. Write a short README explaining how to run it safely.
