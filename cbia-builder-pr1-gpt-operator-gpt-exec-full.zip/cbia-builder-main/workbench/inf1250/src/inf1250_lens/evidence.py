"""
REFERENCE ONLY — NOT EXECUTED

This file is a reference mirror of the GPT-executed Generative Execution DAG (GED).
It MUST NOT be invoked as a controller or execution entrypoint.
"""

"""Evidence and invariant logging (stub)."""
def evidence(name, artifact):
    raise NotImplementedError

def invariant(name, ok, note=""):
    raise NotImplementedError

def log_step(step, observation, decision):
    raise NotImplementedError
