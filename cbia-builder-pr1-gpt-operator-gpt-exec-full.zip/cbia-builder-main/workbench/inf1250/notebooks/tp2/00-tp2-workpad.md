---
jupytext:
  formats: md
kernel:
  name: python3
---

# TP2 Workpad

## 3P
Computation:
Inference:
Control:

## ACS
Plant:
Controller:
Sensors:
Actuators:
Constraints:
Feedback rule:
