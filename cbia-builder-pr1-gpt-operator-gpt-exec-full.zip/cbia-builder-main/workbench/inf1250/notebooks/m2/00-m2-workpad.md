---
jupytext:
  formats: md
kernel:
  name: python3
---

# M2 Workpad

## 3P
Computation:
Inference:
Control:

## ACS
Plant:
Controller:
Sensors:
Actuators:
Constraints:
Feedback rule:
