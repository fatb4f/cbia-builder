# Syllabus (official)

Put official syllabus artifacts here (PDF/MD notes/metadata).

This is input. Downstream stages generate:
- schemas/
- material/
