Module 1: Algorithme et pseudocode | INF 1220 - Introduction à la programmation 

[![Logo](/inf1220-hugo/livre.jpg)INF 1220 - Introduction à la programmation](/inf1220-hugo/)
--------------------------------------------------------------------------------------------

document.querySelector(".book-search").classList.remove("hidden")

*   [Programmation Java en ligne](/inf1220-hugo/docs/environnement/)
*   [Formattage du code Java](/inf1220-hugo/docs/format/)
*   [Vous avez trouvé une erreur?](/inf1220-hugo/docs/erreurs/)
*   [Modules](/inf1220-hugo/docs/modules/)
    *    [Module 1: Algorithme et pseudocode](/inf1220-hugo/docs/modules/module1/)
        *   [Modèle du cours](/inf1220-hugo/docs/modules/module1/teluq/)
        *   [Robot conversationnel et intelligence artificielle](/inf1220-hugo/docs/modules/module1/robot/)
        *   [Autoévaluation](/inf1220-hugo/docs/modules/module1/autoevaluation/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module1/pasapas/)
        *   [Les ordinateurs et leurs langages](/inf1220-hugo/docs/modules/module1/ordinateurs/)
        *   [Les algorithmes](/inf1220-hugo/docs/modules/module1/algorithmes/)
        *   [Les algorithmes : conception et syntaxe](/inf1220-hugo/docs/modules/module1/algorithmes2/)
        *   [Les algorithmes: les structures de contrôle](/inf1220-hugo/docs/modules/module1/algorithmes3/)
        *   [Les problèmes difficiles](/inf1220-hugo/docs/modules/module1/difficile/)
        *   [Complexité algorithmique](/inf1220-hugo/docs/modules/module1/complex/)
        *   [Les erreurs communes](/inf1220-hugo/docs/modules/module1/erreurs/)
        *   [Présentation du pseudocode](/inf1220-hugo/docs/modules/module1/syntaxe/)
        *   [Exercices sur les algorithmes](/inf1220-hugo/docs/modules/module1/exercices/)
        *   [Travail noté 1](/inf1220-hugo/docs/modules/module1/travail-note-1/)
    *    [Module 2: Introduction au langage Java](/inf1220-hugo/docs/modules/module2/)
        *   [Préparation de l’espace de travail](/inf1220-hugo/docs/modules/module2/preparation/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module2/pasapas/)
        *   [Création d'une classe en Java](/inf1220-hugo/docs/modules/module2/oriente/)
        *   [Introduction aux types de base et à leurs opérateurs](/inf1220-hugo/docs/modules/module2/typeoperateur/)
        *   [Exercices sur les classes, les variables, les types et les opérateurs](/inf1220-hugo/docs/modules/module2/exercices-2-1/)
        *   [Méthodes et constructeurs](/inf1220-hugo/docs/modules/module2/methodes/)
        *   [Exercices sur les classes et méthodes](/inf1220-hugo/docs/modules/module2/exercices-2-2/)
        *   [Recommandations](/inf1220-hugo/docs/modules/module2/conseils/)
        *   [MarkDown](/inf1220-hugo/docs/modules/module2/markdown/)
        *   [Gabarit pour les travaux notés 2, 3, 4 et 5](/inf1220-hugo/docs/modules/module2/gabarit/)
        *   [Travail noté 2](/inf1220-hugo/docs/modules/module2/travail-note-2/)
    *    [Module 3: Les structures de données, de contrôle et d'itération en Java](/inf1220-hugo/docs/modules/module3/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module3/pasapas/)
        *   [GitHub](/inf1220-hugo/docs/modules/module3/github/)
        *   [Les structures de contrôle](/inf1220-hugo/docs/modules/module3/activite-3-1/)
        *   [Les structures itératives](/inf1220-hugo/docs/modules/module3/activite-3-2/)
        *   [Les chaînes de caractères (String)](/inf1220-hugo/docs/modules/module3/activite-3-3-string/)
        *   [Les structures de données de base](/inf1220-hugo/docs/modules/module3/activite-3-3/)
        *   [Les valeurs aléatoires](/inf1220-hugo/docs/modules/module3/activite-3-3-random/)
        *   [La programmation fonctionnelle en Java](/inf1220-hugo/docs/modules/module3/fonctionnel/)
        *   [Exercices sur les structures de contrôle, les structures de données, les structures itératives](/inf1220-hugo/docs/modules/module3/exercices-3-1/)
        *   [Les exceptions](/inf1220-hugo/docs/modules/module3/activite-3-4/)
        *   [La récursivité](/inf1220-hugo/docs/modules/module3/activite-3-5/)
        *   [Exercices sur les exceptions et la récursivité](/inf1220-hugo/docs/modules/module3/exercices-3-2/)
        *   [Exemple : modèle de langue](/inf1220-hugo/docs/modules/module3/activite-3-3-modele/)
        *   [Recommandations](/inf1220-hugo/docs/modules/module3/conseils/)
        *   [Travail noté 3](/inf1220-hugo/docs/modules/module3/travail-note-3/)
    *    [Module 4: Les entrées et sorties](/inf1220-hugo/docs/modules/module4/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module4/pasapas/)
        *   [Les flux de console](/inf1220-hugo/docs/modules/module4/activite-4-1/)
        *   [Les flux de données: lecture dans des fichiers et autres](/inf1220-hugo/docs/modules/module4/activite-4-2/)
        *   [Exercices sur les flux](/inf1220-hugo/docs/modules/module4/exercices-4-1/)
        *   [Développement web](/inf1220-hugo/docs/modules/module4/web/)
        *   [Travail noté 4](/inf1220-hugo/docs/modules/module4/travail-note-4/)
    *    [Module 5. La programmation orientée objet: héritage et le polymorphisme](/inf1220-hugo/docs/modules/module5/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module5/pasapas/)
        *   [L'héritage, les classes abstraites et les interfaces](/inf1220-hugo/docs/modules/module5/activite-5-1/)
        *   [Le polymorphisme](/inf1220-hugo/docs/modules/module5/activite-5-2/)
        *   [Exercices sur l’héritage et le polymorphisme](/inf1220-hugo/docs/modules/module5/exercices-5-1/)
        *   [Travail noté 5](/inf1220-hugo/docs/modules/module5/travail-note-5/)
    *   [Examen](/inf1220-hugo/docs/modules/examen/)
*   [Évaluation](/inf1220-hugo/docs/evaluation/)
*   [Pense-bête java](/inf1220-hugo/docs/pensebete/)
*    Autres ressources
    *   [Le professeur](/inf1220-hugo/docs/extra/credits/)
    *   [Feuille de route](/inf1220-hugo/docs/extra/feuille-de-route/)
    *   [Ressources](/inf1220-hugo/docs/extra/ressources/)
    *   [FAQ](/inf1220-hugo/docs/extra/faq/)
    *   [Manuel](/inf1220-hugo/docs/extra/manuel/)
    *   [Rappel mathématique](/inf1220-hugo/docs/extra/math/)
    *   [Intelligence artificielle](/inf1220-hugo/docs/extra/ia/)
    *   [Petit guide d’usage du courriel efficace](/inf1220-hugo/docs/extra/courriel/)

(function(){var e=document.querySelector("aside .book-menu-content");addEventListener("beforeunload",function(){localStorage.setItem("menu.scrollTop",e.scrollTop)}),e.scrollTop=localStorage.getItem("menu.scrollTop")})()

![Menu](/inf1220-hugo/svg/menu.svg)

### Module 1: Algorithme et pseudocode

![Table of Contents](/inf1220-hugo/svg/toc.svg)

*   [Pourquoi ce premier module ?](#pourquoi-ce-premier-module-)
*   [Planification du temps](#planification-du-temps)

Module 1 [#](#module-1)
=======================

Le module 1 pose les bases de l’algorithmique et du raisonnement informatique. Il vous initie à la notion d’algorithme : une suite d’instructions précises permettant de résoudre un problème, à l’image d’une recette de cuisine. Vous apprendrez à décrire ces solutions en pseudocode, un langage intermédiaire entre le français et la programmation, pour exprimer clairement chaque étape sans vous soucier de la syntaxe d’un langage particulier.

Au fil du module, vous découvrirez :

*   Comment identifier les composants essentiels d’un algorithme (entrées, sorties, instructions, conditions, boucles).
*   Comment rédiger des algorithmes simples en pseudocode, en français.
*   Les bases de la complexité algorithmique (notation grand-O, comparaison d’approches).
*   L’importance de la rigueur, de la précision et de la pratique pour progresser.
*   Un aperçu historique des langages de programmation et de l’évolution des ordinateurs.

De nombreux exemples concrets et exercices d’autoévaluation vous permettront d’appliquer ces concepts et de développer votre capacité à raisonner de façon logique et méthodique, compétence essentielle pour la suite du cours et pour toute démarche informatique.

Pourquoi ce premier module ? [#](#pourquoi-ce-premier-module-)
--------------------------------------------------------------

Vous êtes peut-être surpris que le premier module ne débute pas immédiatement avec de la programmation Java. Nous croyons qu’il est essentiel d’établir au préalable des concepts plus fondamentaux. Notre objectif n’est pas de simplement vous aidez à apprendre la programmation en général, mais de vous donner des bases solides.

Il est difficile d’apprendre à programmer sans savoir ce qu’est un algorithme. Vous devez bien maîtriser cette notion fondamentale.

Planification du temps [#](#planification-du-temps)
---------------------------------------------------

Assurez-vous de bien planifier votre temps. N’oubliez pas de consacrer environ 9 heures par semaine au cous. Le cours nécessite plus d’une journée par semaine, pendant quinze semaine.

Nous vous suggérons de consacrer (au maximum) les trois premières semaines du cours au premier module (environ 27 heures). Assurez-vous de remettre le premier travail noté à la fin de la troisième semaine ou avant.

**Vous ne devriez pas prendre plus de trois semaines**. Le cours est riche en contenu, si vous prenez plus de trois semaines pour le premier module vous risquez de manquer de temps pour le reste du cours.

 [![Previous](/inf1220-hugo/svg/backward.svg "Modules") Modules](/inf1220-hugo/docs/modules/) [Modèle du cours ![Next](/inf1220-hugo/svg/forward.svg "Modèle du cours")](/inf1220-hugo/docs/modules/module1/teluq/) 

(function(){function e(e){const t=window.getSelection(),n=document.createRange();n.selectNodeContents(e),t.removeAllRanges(),t.addRange(n)}document.querySelectorAll("pre code").forEach(t=>{t.addEventListener("click",function(){if(window.getSelection().toString())return;e(t.parentElement),navigator.clipboard&&navigator.clipboard.writeText(t.parentElement.textContent)})})})()

*   [Pourquoi ce premier module ?](#pourquoi-ce-premier-module-)
*   [Planification du temps](#planification-du-temps)