Présentation du pseudocode | INF 1220 - Introduction à la programmation 

[![Logo](/inf1220-hugo/livre.jpg)INF 1220 - Introduction à la programmation](/inf1220-hugo/)
--------------------------------------------------------------------------------------------

document.querySelector(".book-search").classList.remove("hidden")

*   [Programmation Java en ligne](/inf1220-hugo/docs/environnement/)
*   [Formattage du code Java](/inf1220-hugo/docs/format/)
*   [Vous avez trouvé une erreur?](/inf1220-hugo/docs/erreurs/)
*   [Modules](/inf1220-hugo/docs/modules/)
    *    [Module 1: Algorithme et pseudocode](/inf1220-hugo/docs/modules/module1/)
        *   [Modèle du cours](/inf1220-hugo/docs/modules/module1/teluq/)
        *   [Robot conversationnel et intelligence artificielle](/inf1220-hugo/docs/modules/module1/robot/)
        *   [Autoévaluation](/inf1220-hugo/docs/modules/module1/autoevaluation/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module1/pasapas/)
        *   [Les ordinateurs et leurs langages](/inf1220-hugo/docs/modules/module1/ordinateurs/)
        *   [Les algorithmes](/inf1220-hugo/docs/modules/module1/algorithmes/)
        *   [Les algorithmes : conception et syntaxe](/inf1220-hugo/docs/modules/module1/algorithmes2/)
        *   [Les algorithmes: les structures de contrôle](/inf1220-hugo/docs/modules/module1/algorithmes3/)
        *   [Les problèmes difficiles](/inf1220-hugo/docs/modules/module1/difficile/)
        *   [Complexité algorithmique](/inf1220-hugo/docs/modules/module1/complex/)
        *   [Les erreurs communes](/inf1220-hugo/docs/modules/module1/erreurs/)
        *   [Présentation du pseudocode](/inf1220-hugo/docs/modules/module1/syntaxe/)
        *   [Exercices sur les algorithmes](/inf1220-hugo/docs/modules/module1/exercices/)
        *   [Travail noté 1](/inf1220-hugo/docs/modules/module1/travail-note-1/)
    *    [Module 2: Introduction au langage Java](/inf1220-hugo/docs/modules/module2/)
        *   [Préparation de l’espace de travail](/inf1220-hugo/docs/modules/module2/preparation/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module2/pasapas/)
        *   [Création d'une classe en Java](/inf1220-hugo/docs/modules/module2/oriente/)
        *   [Introduction aux types de base et à leurs opérateurs](/inf1220-hugo/docs/modules/module2/typeoperateur/)
        *   [Exercices sur les classes, les variables, les types et les opérateurs](/inf1220-hugo/docs/modules/module2/exercices-2-1/)
        *   [Méthodes et constructeurs](/inf1220-hugo/docs/modules/module2/methodes/)
        *   [Exercices sur les classes et méthodes](/inf1220-hugo/docs/modules/module2/exercices-2-2/)
        *   [Recommandations](/inf1220-hugo/docs/modules/module2/conseils/)
        *   [MarkDown](/inf1220-hugo/docs/modules/module2/markdown/)
        *   [Gabarit pour les travaux notés 2, 3, 4 et 5](/inf1220-hugo/docs/modules/module2/gabarit/)
        *   [Travail noté 2](/inf1220-hugo/docs/modules/module2/travail-note-2/)
    *    [Module 3: Les structures de données, de contrôle et d'itération en Java](/inf1220-hugo/docs/modules/module3/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module3/pasapas/)
        *   [GitHub](/inf1220-hugo/docs/modules/module3/github/)
        *   [Les structures de contrôle](/inf1220-hugo/docs/modules/module3/activite-3-1/)
        *   [Les structures itératives](/inf1220-hugo/docs/modules/module3/activite-3-2/)
        *   [Les chaînes de caractères (String)](/inf1220-hugo/docs/modules/module3/activite-3-3-string/)
        *   [Les structures de données de base](/inf1220-hugo/docs/modules/module3/activite-3-3/)
        *   [Les valeurs aléatoires](/inf1220-hugo/docs/modules/module3/activite-3-3-random/)
        *   [La programmation fonctionnelle en Java](/inf1220-hugo/docs/modules/module3/fonctionnel/)
        *   [Exercices sur les structures de contrôle, les structures de données, les structures itératives](/inf1220-hugo/docs/modules/module3/exercices-3-1/)
        *   [Les exceptions](/inf1220-hugo/docs/modules/module3/activite-3-4/)
        *   [La récursivité](/inf1220-hugo/docs/modules/module3/activite-3-5/)
        *   [Exercices sur les exceptions et la récursivité](/inf1220-hugo/docs/modules/module3/exercices-3-2/)
        *   [Exemple : modèle de langue](/inf1220-hugo/docs/modules/module3/activite-3-3-modele/)
        *   [Recommandations](/inf1220-hugo/docs/modules/module3/conseils/)
        *   [Travail noté 3](/inf1220-hugo/docs/modules/module3/travail-note-3/)
    *    [Module 4: Les entrées et sorties](/inf1220-hugo/docs/modules/module4/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module4/pasapas/)
        *   [Les flux de console](/inf1220-hugo/docs/modules/module4/activite-4-1/)
        *   [Les flux de données: lecture dans des fichiers et autres](/inf1220-hugo/docs/modules/module4/activite-4-2/)
        *   [Exercices sur les flux](/inf1220-hugo/docs/modules/module4/exercices-4-1/)
        *   [Développement web](/inf1220-hugo/docs/modules/module4/web/)
        *   [Travail noté 4](/inf1220-hugo/docs/modules/module4/travail-note-4/)
    *    [Module 5. La programmation orientée objet: héritage et le polymorphisme](/inf1220-hugo/docs/modules/module5/)
        *   [Java pas à pas](/inf1220-hugo/docs/modules/module5/pasapas/)
        *   [L'héritage, les classes abstraites et les interfaces](/inf1220-hugo/docs/modules/module5/activite-5-1/)
        *   [Le polymorphisme](/inf1220-hugo/docs/modules/module5/activite-5-2/)
        *   [Exercices sur l’héritage et le polymorphisme](/inf1220-hugo/docs/modules/module5/exercices-5-1/)
        *   [Travail noté 5](/inf1220-hugo/docs/modules/module5/travail-note-5/)
    *   [Examen](/inf1220-hugo/docs/modules/examen/)
*   [Évaluation](/inf1220-hugo/docs/evaluation/)
*   [Pense-bête java](/inf1220-hugo/docs/pensebete/)
*    Autres ressources
    *   [Le professeur](/inf1220-hugo/docs/extra/credits/)
    *   [Feuille de route](/inf1220-hugo/docs/extra/feuille-de-route/)
    *   [Ressources](/inf1220-hugo/docs/extra/ressources/)
    *   [FAQ](/inf1220-hugo/docs/extra/faq/)
    *   [Manuel](/inf1220-hugo/docs/extra/manuel/)
    *   [Rappel mathématique](/inf1220-hugo/docs/extra/math/)
    *   [Intelligence artificielle](/inf1220-hugo/docs/extra/ia/)
    *   [Petit guide d’usage du courriel efficace](/inf1220-hugo/docs/extra/courriel/)

(function(){var e=document.querySelector("aside .book-menu-content");addEventListener("beforeunload",function(){localStorage.setItem("menu.scrollTop",e.scrollTop)}),e.scrollTop=localStorage.getItem("menu.scrollTop")})()

![Menu](/inf1220-hugo/svg/menu.svg)

### Présentation du pseudocode

![Table of Contents](/inf1220-hugo/svg/toc.svg)

*   [Indentation](#indentation)
*   [Terminologie](#terminologie)
*   [Commentaires](#commentaires)
*   [Typographie](#typographie)

Guide pour présenter du pseudocode [#](#guide-pour-pr%c3%a9senter-du-pseudocode)
================================================================================

Adoptez un style simple. Testez la lisibilité de votre pseudocode en le lisant à haute voix.

Voici un exemple de pseudocode difficile à comprendre.

    entrée : un nombre
    si mon nombre nombre > 0 alors "positif"
         autrement
        afficher "négatif ou zéro"
    fin du code
    

Voici un bon exemple.

    entrée : nombre
    si nombre > 0 alors
        afficher "positif"
    sinon
        afficher "négatif ou zéro"
    fin si
    

Indentation [#](#indentation)
-----------------------------

L’indentation est utile pour montrer la structure hiérarchique (boucles, conditions, blocs). Utilisez systématiquement 2 à 4 espaces par niveau, vous pouvez aussi utiliser des tabulations. Ne mélangez pas espaces et tabulations. Indentez chaque bloc intérieur d’un niveau supplémentaire. Alignez les instructions de fin de bloc (comme “fin si” ou “fin pour”) avec le début du bloc. Conservez une indentation cohérente dans tout le document.

    pour i de 1 à 10 faire
        si i mod 2 = 0 alors
            afficher i + " est pair"
        fin si
    fin pour
    

Terminologie [#](#terminologie)
-------------------------------

Employez des termes en français ou en anglais courants, mais ne mélangez pas les langues. Utilisez des mots-clés simples et clairs :

*   entrée, sortie
*   si … alors … sinon … fin si
*   pour … faire … fin pour
*   tant que … faire … fin tant que
*   fonction … retour … fin fonction

Évitez les abréviations obscures.

Commentaires [#](#commentaires)
-------------------------------

Insérez des commentaires avec un préfixe comme “//” ou “#” pour expliquer les parties complexes. Numérotez les lignes seulement pour des algorithmes longs ou des références.

Exemple :

    fonction factorielle(n)  // Calcule n!
        si n <= 1 alors
            retour 1
        sinon
            retour n * factorielle(n-1)
        fin si
    fin fonction
    

Typographie [#](#typographie)
-----------------------------

Utilisez une police à espacement fixe (comme Courier) dans les documents. Évitez les lignes trop longues. Séparez les sections logiques par des lignes vides.

    entrée : nombre
    si nombre > 0 alors
        afficher "positif"
    sinon
        afficher "négatif ou zéro"
    fin si
    
    si nombre > 10 alors
        afficher "nombre plus grand que dix"
    fin si
    

 [![Previous](/inf1220-hugo/svg/backward.svg "Les erreurs communes") Les erreurs communes](/inf1220-hugo/docs/modules/module1/erreurs/) [Exercices sur les algorithmes ![Next](/inf1220-hugo/svg/forward.svg "Exercices sur les algorithmes")](/inf1220-hugo/docs/modules/module1/exercices/) 

(function(){function e(e){const t=window.getSelection(),n=document.createRange();n.selectNodeContents(e),t.removeAllRanges(),t.addRange(n)}document.querySelectorAll("pre code").forEach(t=>{t.addEventListener("click",function(){if(window.getSelection().toString())return;e(t.parentElement),navigator.clipboard&&navigator.clipboard.writeText(t.parentElement.textContent)})})})()

*   [Indentation](#indentation)
*   [Terminologie](#terminologie)
*   [Commentaires](#commentaires)
*   [Typographie](#typographie)